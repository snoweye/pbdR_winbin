##GO## nc_create_preamble is an exact copy of top portion of nc_create
nc_create_preamble <- function(filename, vars, force_v4 = TRUE,
    verbose = FALSE){
  # A serial dummy function.
  invisible()
} # End of nc_create_preamble().


nc_create_finish <- function(nc, preamble, vars, verbose){
  # A serial dummy function.
  invisible()
} # End of nc_create_finish().
