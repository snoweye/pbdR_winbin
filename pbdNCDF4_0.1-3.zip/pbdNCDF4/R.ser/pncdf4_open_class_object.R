
nc_open_class_object <- function(filename, rv, write, readunlim, verbose){
  # A serial dummy function.
  invisible()
} # End of nc_open_class_object().
